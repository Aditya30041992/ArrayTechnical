export class Accordian {
    $key: string;
    left: boolean;
    middle: boolean;
    right: boolean;
}

export class SubGmail {
    $key: string;
    gmailId: string;

}