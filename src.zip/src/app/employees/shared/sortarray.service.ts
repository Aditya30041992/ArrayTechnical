import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SortarrayService {
  accordians=[];
  array=[];


  constructor() { }

 
  get sorted(){
    debugger;
    this.accordians.sort((a, b) => {
      if(a.id === b.id) {
        // If two elements have same number, then the one who has larger rating.average wins
        return a.order - b.order;
      } else {
        // If two elements have different number, then the one who has larger number wins
        return a.number - b.number;
      }
    });
    return this.accordians;
    console.log(this.accordians);
  //   this.accordians.sort((first,second) => {
  //     if(first.id===second.id){
  //     // If two elements have same number, then the one who has larger rating.average wins
  //     return second.order - first.order;
  //   }
  //   else{
  //     return second.order - first.order;
  //   }
  // });
  
  
  // this.array = this.accordians.filter((element, index) => {
  //   // return index === 0 || element.number !== this.array[index-1].number;
  //   this.accordians.filter(item => item.checked);
  // });
}

}
