export class Employee {
    $key: string;
    name: string;
    position: string;
    office: string;
    salary: number;
}
