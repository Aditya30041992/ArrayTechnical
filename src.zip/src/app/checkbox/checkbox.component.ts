import { Component, OnInit } from '@angular/core';
import { SortarrayService } from '../employees/shared/sortarray.service';
import { element } from '@angular/core/src/render3';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.css']
})
export class CheckboxComponent implements OnInit {

  oneAtATime: boolean = true;
  name: string;
  list: any[];
  strings: any[];

  constructor(private sortarrayService:SortarrayService){

  }

  ngOnInit() {
    this.intializeArray();
  
  }

  intializeArray(){
    this.list = [
      {
        id: 1,
        title: 'Gmail',
        checked: false,
        order:1.1
      },
      {
        id:2,
        title: 'Facebook',
        checked: false,
        order:1.2

      },
      {
        id:3,
        title: 'LinkedIn',
        checked: false,
        order:1.3

      },
      {
        id:4,
        title: 'Github',
        checked: false,
        order:1.4

      },
      {
        id:5,
        title: 'Orkut',
        checked: false,
        order:1.5

      },
    ],
    this.strings = []

  }

addItems(obj){
  debugger;
  this.sortarrayService.accordians.push(obj);
  // const matchedAccordionObject = this.list.filter(listObj => {
  //   return obj.id = listObj.id;
  // })[0];
  
  // matchedAccordionObject.checkbox ? this.tempArr.push(matchedAccordionObject) :  this.tempArr.slice(matchedAccordionObject) ;
  // this.sortarrayService.sorted(this.tempArr);
}


get sorting() {
  debugger;
  //return this.sortarrayService.sotred.filter(item => item.checked);
  this.sortarrayService.sorted.filter((element, index) => {
    return index === 0 || element.id !== this.sortarrayService.accordians[index-1].id;
  });
  return this.sortarrayService.sorted;
  
}


  onSend(value) {
    this.strings.push(value + "-" + this.name);
    console.log(this.strings);
    this.name = "";
  }

}


